

create database sales

use sales


create table product
(
pid int,
pname varchar(100),
price int,
quantity int
)


create table  customer 
(
cid int,
name varchar(100),
email varchar(100),
dob  datetime,
phoeno int
)


insert into product
values(1,'dove',40,1000)

insert into product
values(2,'iphone',67000,100)

select * from product 



----
create database Books

use Books

create table Author(
Title varchar(100),
pages int,
company varchar(100),
author varchar(100),
price int,
)

insert into Author 
values('Wave',240,'sigma','Daniel',250)

insert into Author 
values('Trump',240,'pixel','John Quint',250)

select * from Author
